<!DOCTYPE html>
<html>
<title>admin home</title>
<head>


<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="admin_home.css">
</head>
<body>
	<header class="header">
	<a href="">Admin Dashboard</a>
	<div class="logout">
	<a href="logout.php">LogOut</a>
	</div>
	</header>
	<aside>
	<ul style="
    padding-top: 50px;">
		
		<li>
		<a href="add_employee.php">Add Employe</a>
		</li>
		<li>
		<a href="view_employee.php">View Employe</a>
		</li>
		<li>
		<a href="view_attendance.php">Attendance</a>
		</li>
		<li>
		<a href="emp_areportdw.php">Generate Report</a>
		</li>
		
		
	</ul>
	</aside>
	<div class="content">
		








	</div>	


      
</body>
</html>
