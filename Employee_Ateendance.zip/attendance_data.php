<?php 

include 'db_connection.php';

if(isset($_POST['submit'])){
    $fname=$_POST['fname'];
     $mno=$_POST['mno'];
    $email=$_POST['email'];
    $date=$_POST['date'];
 $intime=$_POST['intime'];
$outtime=$_POST['outtime'];
   
    
        $sql="INSERT INTO emp_attendance(fname,mno,email,date,intime,outtime)
                       VALUES ('$fname','$mno','$email','$date','$intime','$outtime')";
	if($conn->query($sql)==TRUE){
                header("location: view_attendance.php");
            }
            else{
                echo "Error:".$conn->error;
            }

	
}

?>
           