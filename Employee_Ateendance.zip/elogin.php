
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="htmlcss.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Login</title>
    <link rel="stylesheet" href=https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css>
    
<body>
    <div class="container">
                <div class="header">
                    <div class="navname">
                        <h2><?php echo "Emloyee Attendance System"; ?></h2>
                    </div>
                 
                    <div class="navbar">
                        <ul>
                        <li><a class="active" href="first.php">Home</a></li>
                        </ul>
                    </div>
               </div>  
    
            <div class="infocontainer">
                
                <div class="infomain">
	 <div class="container1" id="signup" style="display:none; height: 600px;width: 550px;"">
      <h1 class="form-title">Employee  Register</h1><br>
      <form method="post" action="eregister.php" >
        <div class="input-group">
          
	  <label for="fname">Full Name</label><br>
           <input type="text" name="fname" id="fname" placeholder="Full Name" required>
           
        </div><br>
        
	 <div class="input-group">
         
	 <label for="email">Mobile Number</label><br>
            <input type="number" name="mno" id="mno" placeholder="Mobile Number" required>
           
        </div><br>
        <div class="input-group">
         
         <label for="email"> DOB</label><br>
                <input type="date" name="dob" id="mno" placeholder="Date of Birth" required>
               
            </div><br>
    

        <div class="input-group">
           
	 <label for="email">Email</label><br>
            <input type="email" name="email" id="email" placeholder="Email" required>
           
        </div><br>
        
        <div class="input-group">
            
	<label for="password">Password</label><br>
            <input type="password" name="pass" id="password" placeholder="Password" required>
            
        </div><br>
<div class="input-group">
            
	    <label for="lName">Adress</label><br>
            <input type="text" name="adress" id="lname" placeholder="Adress" required>
            
        </div><br>
       <input type="submit" class="btn" value="Sign Up" name="signup">
      </form>
      <p class="or">
        ----------or--------
      </p>
      
      <div class="links">
        <p>Already Have Account ?</p>
     <button id="signInButton" >SignIn</button>
      </div>
    </div>

    <div class="container1" id="signIn" style="height: 430px;width: 450px;">
        <h1 class="form-title">Employee Login</h1><br>
        <form method="post" action="eregister.php">
          <div class="input-group">
              
	<label for="email">Email</label><br>
              <input type="email" name="email" id="email" placeholder="Email" required>
          </div><br>
          <div class="input-group">
           
	<label for="password">Password</label><br>
              <input type="password" name="password" id="password" placeholder="Password" required><br>
              
          </div><br>
          <p class="recover">
            <a href="#">Recover Password</a>
          </p><br>
         <input type="submit" class="btn" value=" Sign In" name="signin">
        </form>
        <p class="or">
          ----------or--------
        </p>
        
        <div class="links">
          <p>Don’t have account yet?</p>
          <button id="signUpButton" >Sign Up</button>
        </div>
      </div>
      <script src="script.js"></script>
                  
                </div>

            </div>
 
    </div>
    
</body>



