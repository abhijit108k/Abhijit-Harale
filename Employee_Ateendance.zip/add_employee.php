<!DOCTYPE html>
<html>
<title>Add employe</title>
<head>
<?php

include ('botstrap.php');
?>

<?php

include ('admin_home.php');
?>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="admin_home.css">
</head>
<body>
	
	<div class="content">
		
<form  action="add_eployeedata.php" method="post" style="margin-right:150px;">

	<div class="form-group">
    <label for="exampleInputEmail1">Full Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" name="fname"  placeholder="Enter Your Full Name">
  
  </div>

	<div class="form-group">
    <label for="exampleInputEmail1">Mobile Number</label>
    <input type="number" class="form-control" id="exampleInputEmail1" name="mno" placeholder="Enter Your Mobile Number">
  
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email"placeholder="Enter Your email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Password</label>
    <input type="password" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="pass"placeholder="Create Your Password">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
    
  <div class="form-group">
    <label for="exampleInputPassword1">Date Of Birth</label>
    <input type="date" class="form-control" id="exampleInputPassword1" name="dob" placeholder="Password">

  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Adress</label>
    <input type="text" class="form-control" id="exampleInputEmail1" name="adress" aria-describedby="emailHelp" placeholder="Enter Your Adress">
 
</div>
 <button type="submit" class="btn btn-primary" name="submit">Submit</button>
</form>






	</div>	


      
</body>
</html>
