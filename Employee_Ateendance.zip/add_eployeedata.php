<?php 

include 'db_connection.php';

if(isset($_POST['submit'])){
    $fname=$_POST['fname'];
     $mno=$_POST['mno'];
    $email=$_POST['email'];
    $dob=$_POST['dob'];
 $adress=$_POST['adress'];
 $pass=$_POST['pass'];

   
    
        $sql="INSERT INTO emp(fname,mno,email,dob,adress,password)
                       VALUES ('$fname','$mno','$email','$dob','$adress','$pass')";
	if($conn->query($sql)==TRUE){
                header("location: view_employee.php");
            }
            else{
                echo "Error:".$conn->error;
            }

	
}

?>
           