<!DOCTYPE html>
<html>
<title>employee_home</title>
<head>


<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="admin_home.css">
</head>
<body>
	<header class="header">
	<a href="">Employee Dashboard</a>
	<div class="logout">
	<a href="logout.php">LogOut</a>
	</div>
	</header>
	<aside>
	<ul style="
    padding-top: 50px;">
		
	<li>
		<a href="emp_profile.php">Profile</a>
		</li>
		
	
		<li>
		<a href="emp_attendance.php">Attendance</a>
		</li>
		<li>
		<a href="emp_report.php">Report</a>
		</li>

		
		<li>
		<a href="empdw.php">Date Wise Report</a>
		</li>
		
	</ul>
	</aside>
	<div class="content">
	

	</div>	


      
</body>
</html>
