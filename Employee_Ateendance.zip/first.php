<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="styles.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee home page</title>
    
</head>
<body>
    <div class="container">
                <div class="header">
                    <div class="navname">
                        <h2><?php echo "Emloyee Attendance System"; ?></h2>
                    </div>
                 
                    
               </div>  
    
       
    
            <div class="btn1">
                <div class="employee">
                 <a href="elogin.php"><button class="button button1">Employee</button></a>
                </div>
                <div class="admin">
               <a href="alogin.php"><button class="button button2">Admin</button></a>
				
                </div>
             </div>
            <div class="infocontainer">
                <h6>.</h6>
                <div class="infomain">
                    <div class="infomain1">
<pre><h1>Attendance 
Management 
System</h1></pre><pre> Get an Efficient Attendance Management System to 
Monitor Your Employe Growth.</pre>
					</div>
					<div class="infomain2"><img src="empa.jpeg" height="300px">
					</div>
                </div>

            </div>
 
    </div>
</body>
