<!DOCTYPE html>
<html>
<title>Emp attendance</title>
<head>
<?php

include ('botstrap.php');
?>

<?php

include ('emp_home.php');
?>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="admin_home.css">
</head>
<body>
	
	<div class="content">

    <?php
include 'db_connection.php';
session_start();

$attendanceRecords = []; 

if (isset($_POST['submit'])) {
    $adate = $_POST['adate'];

    
    $stmt = $conn->prepare("SELECT id,fname,mno,date,email,intime,outtime FROM emp_attendance WHERE date = ? && email=?");
    $stmt->bind_param("ss", $adate,$_SESSION['email']);  
    $stmt->execute();

    
    $result = $stmt->get_result();
    
    
    while ($row = $result->fetch_assoc()) {
        $attendanceRecords[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Report</title>
    <style>
.table_th{
padding:10px;
font-size:25px;
}
.table_td{
padding:10px;
font-size:20px;
background-color:rgb(5, 34, 255);
color:white;
}
.bt{
	margin-top:50px;
	margin-left:300px;
	font-size:20px;

}
</style>

</head>
<body>
    <h1>Date-wise Attendance Report</h1>
    <form method="POST" action="">
        <label for="date">Select Date:</label>
        <input type="date" name="adate" required>
        <button type="submit" name="submit">Generate Report</button>
    </form>

    <?php if (!empty($attendanceRecords)): ?>
        <h2>Attendance for <?php echo htmlspecialchars($adate); ?></h2>
        <table border="2">
            <thead>
                <tr>
                    <th class="table_th">Employee ID</th>
                    <th class="table_th">Name</th>
                    
                    <th class="table_th">Email</th>
                    <th class="table_th">Attendance Date</th>
                    <th class="table_th">In Time</th>
                    <th class="table_th">Out Time</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($attendanceRecords as $record): ?>
                    <tr>
                        <td class="table_td"><?php echo htmlspecialchars($record['id']); ?></td>
                        <td class="table_td"><?php echo htmlspecialchars($record['fname']); ?></td>
                        
                        <td class="table_td"><?php echo htmlspecialchars($record['email']); ?></td>
                        <td class="table_td"><?php echo htmlspecialchars($record['date']); ?></td>
                        <td class="table_td"><?php echo htmlspecialchars($record['intime']); ?></td>
                        <td class="table_td"><?php echo htmlspecialchars($record['outtime']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="bt"> <button onclick="window.print()">Print Report</button></div>


    <?php else: ?>
        <p>No records found for this date.</p>
    <?php endif; ?>
</body>
</html>

		


</div>	


      
</body>
</html>
