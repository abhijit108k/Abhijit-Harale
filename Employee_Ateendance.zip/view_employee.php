<?php
session_start();
if(isset($SESSION['email']))
{
header("location:emp_profile.php");
}

$sname= "localhost";
$unmae= "root";
$password = "";
$db_name = "eam";
$conn = mysqli_connect($sname, $unmae, $password, $db_name);

$sql="select * from emp";

$result=mysqli_query($conn,$sql);
$info=$result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<title>Profile</title>
<head>
<style>
.table_th{
padding:10px;
font-size:25px;
}
.table_td{
padding:10px;
font-size:20px;
background-color:rgb(5, 34, 255);
color:white;
}
.bt{
	margin-top:50px;
	margin-left:300px;
	font-size:20px;

}
</style>
<?php

include ('botstrap.php');
?>

<?php

include ('admin_home.php');
?>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="admin_home.css">
</head>
<body>	
	
	<div class="content">
	<table border="2px">
	<tr>
	<th class="table_th">ID</th>
	<th class="table_th">Full Name</th>
	<th class="table_th">Mobile No</th>
	<th class="table_th">Email</th>
	<th class="table_th">DOB</th>
	<th class="table_th">Adress</th>
	


	</tr>
	<?php
	while($info=$result->fetch_assoc())
	{
	 ?>

	<tr>
	
	<td class="table_td">
	<?php echo "{$info['id']}"; ?>

	</td>
	<td class="table_td">
	<?php echo "{$info['fname']}"; ?>
	</td>
	<td class="table_td"><?php echo "{$info['mno']}"; ?>
	</td>
	<td class="table_td"><?php echo "{$info['email']}"; ?>
	</td>
	<td class="table_td"><?php echo "{$info['dob']}"; ?>
	</td>
	
	
	</td>
	<td class="table_td"><?php echo "{$info['adress']}"; ?>
	</td>
	
	</tr>
	<?php
	}
	 ?>

	 

	</table>
	<div class="bt"> <button onclick="window.print()">Print Report</button></div>



	</div>	
	


      
</body>
</html>
