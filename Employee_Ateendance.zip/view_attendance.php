<!DOCTYPE html>
<html>
<title>view attendance</title>
<head>
<style>
.table_th{
padding:10px;
font-size:25px;
}
.table_td{
padding:10px;
font-size:20px;
background-color:rgb(5, 34, 255);
color:white;
}
.table_bt{
	padding:10px;
font-size:20px;
background-color:rgb(5, 34, 255);
color:black;
}
.bt{
	margin-top:50px;
	margin-left:300px;
	font-size:20px;

}



</style>
<?php

include ('botstrap.php');
?>
<?php
include ('admin_home.php');
?>
<?php
$sname= "localhost";
$unmae= "root";
$password = "";
$db_name = "eam";
$conn = mysqli_connect($sname, $unmae, $password, $db_name);

$sql="select * from emp_attendance";

$result=mysqli_query($conn,$sql);

?>


<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="admin_home.css">
</head>
<body>
	<div class="content">
	<table border="2px">
	<tr>
	<th class="table_th">ID</th>
	<th class="table_th">Full Name</th>
	<th class="table_th">Mobile Number</th>
	<th class="table_th">email</th>
	<th class="table_th">Date</th>
	<th class="table_th">In Time</th>
	<th class="table_th">Out Time</th>


	</tr>
	<?php
	while($info=$result->fetch_assoc())
	{
	 ?>

	<tr>
	
	<td class="table_td">
	<?php echo "{$info['id']}"; ?>

	</td>
	<td class="table_td"><?php echo "{$info['fname']}"; ?>
	</td>
	<td class="table_td"><?php echo "{$info['mno']}"; ?>
	</td>
	<td class="table_td"><?php echo "{$info['email']}"; ?>
	</td>
	<td class="table_td"><?php echo "{$info['date']}"; ?>
	</td>
	<td class="table_td"><?php echo "{$info['intime']}"; ?>
	</td>
	<td class="table_td"><?php echo "{$info['outtime']}"; ?>
	</td>

	
	</tr>
	<?php
	}
	 ?>

	</table>
	<div class="bt"> <button onclick="window.print()">Print Report</button></div>

	</div>	
	



      
</body>
</html>
