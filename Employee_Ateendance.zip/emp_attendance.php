<!DOCTYPE html>
<html>
<title>Emp attendance</title>
<head>
<?php

include ('botstrap.php');
?>

<?php

include ('emp_home.php');
?>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="admin_home.css">
</head>
<body>
	
	<div class="content">
		
<form  action="attendance_data.php" method="post" style="margin-right:150px;">

	<div class="form-group">
    <label for="exampleInputEmail1">Full Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" name="fname"  placeholder="Enter Your Full Name">
  
  </div>

	<div class="form-group">
    <label for="exampleInputEmail1">Mobile Number</label>
    <input type="number" class="form-control" id="exampleInputEmail1" name="mno" placeholder="Enter Your Mobile Number">
  
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email"placeholder="Enter Your email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
<div class="form-group">
    <label for="exampleInputEmail1">Date</label>
    <input type="date" class="form-control" id="exampleInputEmail1" name="date" placeholder="Date">
 
</div>

  <div class="form-group">
    <label for="exampleInputEmail1">IN</label>
    <input type="time" class="form-control" id="exampleInputEmail1" name="intime" placeholder="Enter Your Adress">
 
</div>
<div class="form-group">
    <label for="exampleInputEmail1">Out</label>
    <input type="time" class="form-control" id="exampleInputEmail1" name="outtime" placeholder="Enter Your Adress">
 
</div>
 <button type="submit" class="btn btn-primary" name="submit">Submit</button>
</form>





</div>	


      
</body>
</html>
