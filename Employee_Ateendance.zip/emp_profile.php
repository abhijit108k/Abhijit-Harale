<!DOCTYPE html>
<html>
<title>employee_home</title>
<head>
<?php

include ('emp_home.php');
?>


<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="admin_home.css">
<style>



.container {
    max-width: 600px;
    margin: auto;
    background: #fff;
    padding: 50px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    color: #333;
}

.profile-info p {
    margin: 10px 0;
	padding:10px;
	font-size :20px;
}

strong {
    color: #555;
	font-size :20px;
}

	</style>
</head>
<body>
	<div class="content">
	<?php
session_start();
include 'db_connection.php';


if (!isset($_SESSION['email'])) {
    header("Location: elogin.php");
    exit();
}


$stmt = $conn->prepare("SELECT * FROM emp WHERE email = ?");
$stmt->bind_param("s", $_SESSION['email']); 
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "User not found.";
    exit();
}
?>


<div class="container">
        <h1>Welcome, <?php echo htmlspecialchars($user['fname']); ?></h1>
        <div class="profile-info">
            <p><strong>Mobile No:</strong> <?php echo htmlspecialchars($user['mno']); ?></p>
            <p><strong>Email Adress:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
            <p><strong>Date Of Birth:</strong> <?php echo htmlspecialchars($user['dob']); ?></p>
            <p><strong>Adress:</strong> <?php echo htmlspecialchars($user['adress']); ?></p>
        </div>
        
    </div>



	</div>	


      
</body>
</html>
