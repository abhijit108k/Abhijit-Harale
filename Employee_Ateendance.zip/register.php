<?php 

include 'db_connection.php';

if(isset($_POST['signup'])){
    $fname=$_POST['fname'];
     $mno=$_POST['mno'];
    $email=$_POST['email'];
    $password=$_POST['password'];
 $adress=$_POST['adress'];
   
   
     $checkEmail="SELECT * From admin where email='$email'";
     $result=$conn->query($checkEmail);
     if($result->num_rows>0){
        echo "Email Address Already Exists !";
     }
     else{
        $insertQuery="INSERT INTO admin(fname,mno,email,password,adress)
                       VALUES ('$fname','$mno','$email','$password','$adress')";
            if($conn->query($insertQuery)==TRUE){
                header("location: elogin.php");
            }
            else{
                echo "Error:".$conn->error;
            }
     }
   

}

if(isset($_POST['signin'])){
   $email=$_POST['email'];
   $password=$_POST['password'];
   
   $sql="SELECT * FROM admin WHERE email='$email' and password='$password'";
   $result=$conn->query($sql);
   if($result->num_rows>0){
    session_start();
    $row=$result->fetch_assoc();
    $_SESSION['email']=$row['email'];
    header("Location: add_employee.php");
    exit();
   }
   else{
    echo "Not Found, Incorrect Email or Password";
	
    header("Location: elogin.php");
   }

}
?>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     