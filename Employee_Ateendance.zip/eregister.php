<?php 

include 'db_connection.php';

if(isset($_POST['signup'])){
    $fname=$_POST['fname'];
     $mno=$_POST['mno'];
    $email=$_POST['email'];
    $password=$_POST['password'];
 $adress=$_POST['adress'];
 $pass=$_POST['pass'];
   
   
     $checkEmail="SELECT * From emp where email='$email'";
     $result=$conn->query($checkEmail);
     if($result->num_rows>0){
        echo "Email Address Already Exists !";
     }
     else{
        $sql="INSERT INTO emp(fname,mno,email,dob,adress,password)
                       VALUES ('$fname','$mno','$email','$dob','$adress','$pass')";     
                       
                       if($conn->query($sql)==TRUE){
                header("location: elogin.php");
            }
            else{
                echo "Error:".$conn->error;
            }
     }
   

}

if(isset($_POST['signin'])){
   $email=$_POST['email'];
   $password=$_POST['password'];
   
   $sql="SELECT * FROM emp WHERE email='$email' and password='$password'";
   $result=$conn->query($sql);
   if($result->num_rows>0){
    session_start();
    $row=$result->fetch_assoc();
    $_SESSION['email']=$row['email'];
    header("Location: emp_profile.php");
    exit();
   }
   else{
    echo "Not Found, Incorrect Email or Password";
	
    header("Location: elogin.php");
   }

}
?>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     