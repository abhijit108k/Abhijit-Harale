<?php
include 'db_connection.php';

$attendanceRecords = []; 

if (isset($_POST['submit'])) {
    $adate = $_POST['adate'];

    
    $stmt = $conn->prepare("SELECT id,fname,mno,date,email,intime,outtime FROM emp_attendance WHERE date = ?");
    $stmt->bind_param("s", $adate);  
    $stmt->execute();

    
    $result = $stmt->get_result();
    
    
    while ($row = $result->fetch_assoc()) {
        $attendanceRecords[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Report</title>
</head>
<body>
    <h1>Date-wise Attendance Report</h1>
    <form method="POST" action="">
        <label for="date">Select Date:</label>
        <input type="date" name="adate" required>
        <button type="submit" name="submit">Generate Report</button>
    </form>

    <?php if (!empty($attendanceRecords)): ?>
        <h2>Attendance for <?php echo htmlspecialchars($adate); ?></h2>
        <table border="1">
            <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>Name</th>
                    <th>Mobile Number</th>
                    <th>Email</th>
                    <th>Attendance Date</th>
                    <th>In Time</th>
                    <th>Out Time</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($attendanceRecords as $record): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($record['id']); ?></td>
                        <td><?php echo htmlspecialchars($record['fname']); ?></td>
                        <td><?php echo htmlspecialchars($record['mno']); ?></td>
                        <td><?php echo htmlspecialchars($record['email']); ?></td>
                        <td><?php echo htmlspecialchars($record['date']); ?></td>
                        <td><?php echo htmlspecialchars($record['intime']); ?></td>
                        <td><?php echo htmlspecialchars($record['outtime']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No records found for this date.</p>
    <?php endif; ?>
</body>
</html>
