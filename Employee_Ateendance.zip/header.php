﻿
<html>
<head>
<?php 

?>
<title>Header</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>
*{
margin:0px;
}
.container{
background-color:white;
display:flex;
}
.logo{
margin-right:180px;
margin-left:10px;
}
</style>
</head>
<body>
<div class="container">
<div class="logo"><img src="clogo.png" height="100px"></div>
<h1><div class="well text-left">Employee Attendance System</div></h1>

</div>
</body>
</html>