<?php

include ('emp_home.php');
?>
<!DOCTYPE html>
<html>
<title>employee_home</title>
<head>
<style>
.table_th{
padding:10px;
font-size:25px;
}
.table_td{
padding:10px;
font-size:20px;
background-color:rgb(5, 34, 255);
color:white;
}
.bt{
	margin-top:50px;
	margin-left:300px;
	font-size:0px;
}

</style>


<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="admin_home.css">
</head>
<body>
	<div class="content">



<?php
session_start();
include 'db_connection.php';


if (!isset($_SESSION['email'])) {
    header("Location: elogin.php");
    exit();
}


$stmt = $conn->prepare("SELECT * FROM emp_attendance WHERE email = ?");
$stmt->bind_param("s", $_SESSION['email']); 
$stmt->execute();
$result = $stmt->get_result();
$info= $result->fetch_assoc();

if (!$info) {
    echo "Repost not found.";
    exit();
}
?>


	<table border="1px">
	<tr>
	<th class="table_th">ID</th>
	<th class="table_th">Full Name</th>
	<th class="table_th">Mobile Number</th>
	<th class="table_th">email</th>
	<th class="table_th">Date</th>
	<th class="table_th">In Time</th>
	<th class="table_th">Out Time</th>


	</tr>
	


	<tr>
	
	<td class="table_td">
	<?php echo "{$info['id']}"; ?>

	</td>
	<td class="table_td"><?php echo "{$info['fname']}"; ?>
	</td>
	<td class="table_td"><?php echo "{$info['mno']}"; ?>
	</td>
	<td class="table_td"><?php echo "{$info['email']}"; ?>
	</td>
	<td class="table_td"><?php echo "{$info['date']}"; ?>
	</td>
	<td class="table_td"><?php echo "{$info['intime']}"; ?>
	</td>
	<td class="table_td"><?php echo "{$info['outtime']}"; ?>
	</td>

	
	</tr>
	

	</table>

	<div class="bt"> <button onclick="window.print()">Print Report</button></div>


</div>
	


      
</body>
</html>
